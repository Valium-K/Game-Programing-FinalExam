﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallingPlatform : MonoBehaviour
{
	//public Rigidbody2D playerRigidBody;
	
	private void OnCollisionEnter2D(Collision2D collision) {
		Debug.Log("asdf");	
		gameObject.GetComponent<Rigidbody2D>().constraints =RigidbodyConstraints2D.None;
		gameObject.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
	}
}
